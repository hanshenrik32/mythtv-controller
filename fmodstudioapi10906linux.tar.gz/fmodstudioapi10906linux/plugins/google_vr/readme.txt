# Google VR Audio SDK for [FMOD](http://www.fmod.org/) v0.4.0

Enables high-quality spatial audio for VR on mobile and desktop platforms.

To get started read the online [documentation](https://developers.google.com/vr/audio/fmod-getting-started).

Copyright (c) 2017 Google Inc. All rights reserved.
