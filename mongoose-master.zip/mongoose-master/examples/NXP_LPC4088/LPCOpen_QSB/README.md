Please download the [LPCOpen QSB SDK](https://www.embeddedartists.com/sites/default/files/support/qsb/lpc4088/lpcopen_2_10_lpcxpresso_arm_university_4088qsb.zip) and unpack it into this directory.
