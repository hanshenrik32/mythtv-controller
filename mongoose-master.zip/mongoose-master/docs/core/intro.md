---
title: Misc API
items:
  - { name: ../c-api/net.h }
  - { name: ../c-api/util.h }
  - { name: ../c-api/uri.h }
  - { name: ../c-api/mbuf.h }
---
