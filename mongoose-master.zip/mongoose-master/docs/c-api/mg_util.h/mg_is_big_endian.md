---
title: "mg_is_big_endian()"
decl_name: "mg_is_big_endian"
symbol_kind: "func"
signature: |
  int mg_is_big_endian(void);
---

Returns true if target platform is big endian. 

