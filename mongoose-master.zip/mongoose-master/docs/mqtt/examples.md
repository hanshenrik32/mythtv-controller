# Examples

- [Client example](https://github.com/cesanta/mongoose/tree/master/examples/mqtt_client)
- [Server example](https://github.com/cesanta/mongoose/tree/master/examples/mqtt_broker)

